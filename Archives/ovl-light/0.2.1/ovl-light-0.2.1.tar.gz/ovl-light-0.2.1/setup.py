from distutils.core import setup
setup(
    name='ovl-light',
    packages=['ovl'],
    version='0.2.1',
    license='apache-2.0',
    author='Ori Ben-Moshe',
    author_email='ovl.contact.help@gmail.com',
    description='A light version of the Python Module for Object tracking vision for Robots, ovl',
    url='https://github.com/1937Elysium/Ovl-Python',
    install_requires=['numpy',  'pynetworktables'],
    classifiers=['Development Status :: 4 - Beta',
                 'License :: OSI Approved :: Apache Software License',
                 'Programming Language :: Python :: 2.7',
                 'Programming Language :: Python',
                 'Programming Language :: Python :: 3.4',
                 'Programming Language :: Python :: 3.5',
                 'Programming Language :: Python :: 3.6',
                 'Programming Language :: Python :: 3.7',
                 ]
     )